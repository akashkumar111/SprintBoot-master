package com.reed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaPart3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
